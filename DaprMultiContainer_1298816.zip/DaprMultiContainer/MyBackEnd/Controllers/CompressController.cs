﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MyBackEnd.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CompressController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };
        

        [HttpGet(Name = "GetCompress")]
        public IEnumerable<Compress> Get()
        {
            string token = "No Ingeniero";
            string cadena = "Esta es una cadena";

            LZ milz = new LZ();

            if (token == "Ingeniero")
            {
                return Enumerable.Empty<Compress>();
            }
            else
            {
                return Enumerable.Range(1, 5).Select(index => new Compress
                {
                    cadena = cadena,
                    compressCadena = milz.Compress(cadena),
                    token = token
                })
            .ToArray();
            }
            
        }
        // GET api/<CompressController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<CompressController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<CompressController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<CompressController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
