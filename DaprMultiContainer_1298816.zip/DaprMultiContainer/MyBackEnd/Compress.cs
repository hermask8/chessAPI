﻿namespace MyBackEnd
{
    public class Compress
    {
        public string cadena { get; set; }

        public string compressCadena { get; set; }

        public string token { get; set; }
    }
}
