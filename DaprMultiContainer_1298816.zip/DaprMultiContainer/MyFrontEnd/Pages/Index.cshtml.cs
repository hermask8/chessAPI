﻿using Dapr.Client;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFrontEnd.Pages;

public class IndexModel : PageModel
{
    private readonly DaprClient _daprClient;

    public IndexModel(DaprClient daprClient)
    {
        _daprClient = daprClient;
    }

    public async Task OnGet()
    {
        var forecasts = await _daprClient.InvokeMethodAsync<IEnumerable<Compress>>(
            HttpMethod.Get,
            "MyBackEnd",
            "compress");

        ViewData["WeatherForecastData"] = forecasts;
    }

    public async Task OnGet2()
    {
        var forecasts = await _daprClient.InvokeMethodAsync<IEnumerable<Compress>>(
            HttpMethod.Get,
            "MyBackEnd",
            "compress");

        ViewData["WeatherForecastData"] = forecasts;
    }
}